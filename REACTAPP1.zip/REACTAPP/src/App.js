import React from 'react';
import logo from './logo.svg';
import './App.css';
import {CourseComponent} from './course.component'
import {Listofcourses} from './Listofcourse'
import Posts from './post.component'
import Post from './postwithredux'
import {Switch,Route,Link} from 'react-router-dom'
import {FuncComponent} from './functionalcomponent'

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );

class App extends React.Component
{
  render(){
  // {console.log(this.props)//return <Posts />
  // return <Listofcourses {...this.props} /> //spread operator
   return <div>


<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Online Shopping</Link>
    </div>
    <ul className="nav navbar-nav">
      <li><Link to="/">Home</Link></li>
       <li><Link to="/posts">POST DATA</Link></li>
     <li><Link to="/func">Functional component</Link></li>
    </ul>
  </div>
</nav>

















<Switch>
<Route exact path="/" render={() => <Listofcourses {...this.props} />}></Route>
<Route exact path="/posts" render={() => <Post {...this.props} />}></Route>
<Route exact path="/func" render={() => <FuncComponent {...this.props} />}></Route>
</Switch>
</div>
}





}

export default App;
