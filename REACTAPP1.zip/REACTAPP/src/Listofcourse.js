import React from 'react';
import { CourseComponent } from './course.component';
import axios from 'axios'

export  class Listofcourses extends React.Component {
    constructor(props) {
        super(props);
        console.log(this.props.allcourses)
        //{ name: 'Java', image: "https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png", price: 3000, likes: 1000, location: "pune" },
       //{ name: '.Net', image: "https://s3.amazonaws.com/dev.assets.neo4j.com/wp-content/uploads/dotnet-logo.png", price: 4000, likes: 2000, location: "Bangalore" },{ name: 'Python', image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7BLm4Poe8sSsOaUdrLDpG73RInz0yX20xxETXA4dbjTKohIn8&s", price: 3000, likes: 1000, location: "pune" },
    
        this.img = "https://theme.zdassets.com/theme_assets/1073405/5ca1ed9007049470043d5b8b85ba79d081e268a4.png";
        }



    componentDidMount() {
        axios.get('https://api.myjson.com/bins/19ab30').then(
            // response => console.log(response.data)  //displayed in console
            response => this.props.FetchCourses(response.data)  //to display in ui
        )
    }





    render() {

        let coursesToBeCreated = this.props.allcourses.map(c => <CourseComponent key={c.id} coursedetails={c} {...this.props}/>);
        // return <div><img src={this.img} height="50 px" width="500px" /><CourseComponent coursedetails={this.course1} /><CourseComponent coursedetails={this.course2} /></div>
    return <div><img src={this.img}/><div className="jumbotron"><h1>Online courses</h1></div><div className="row">{coursesToBeCreated}</div></div>
}

}