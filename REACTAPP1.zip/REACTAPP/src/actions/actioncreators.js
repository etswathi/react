export function IncrementCourseLikes(theId){//action creator

return{type:'INCREMENT_LIKES',theId:theId};//action
}

export function DeleteCourse(theId){

    return{type:'DELETE_COURSE',theId:theId};
}

export function DeletePost(theId){


return{type:'DELETE_POST',theId:theId};
}

export function FetchCourses(response){
    return{type:'FETCH_COURSES',response};
}


export function FetchPosts(response){
    return{type:'FETCH_POST',response};
}


