import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import * as  AllActions from './actions/actioncreators';
import App from './App';



//make store as props available to component
function mapStateToProps(storeDataFromProvider){
    return{
        allcourses:storeDataFromProvider.courses,
        allposts:storeDataFromProvider.posts
    }
}


//make actioncreators as props available to component
function mapDispatchToProps(dispatcher){
    return bindActionCreators(AllActions,dispatcher);
}


//map parameters with app
export var EnhancedApp=connect(mapStateToProps,mapDispatchToProps)(App)