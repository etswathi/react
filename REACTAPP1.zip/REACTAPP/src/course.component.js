import React from 'react';
export class CourseComponent extends React.Component{

    constructor(props){
        super(props);
      //  this.state={count:this.props.coursedetails.likes};
            
    }
IncreementLikes(){
    
    //this.setState({count:this.state.count + 1})
this.props.IncrementCourseLikes(this.props.coursedetails.id);

}
DeleteCourse1(){

   this.props.DeleteCourse(this.props.coursedetails.id);

}




    render()
    {return<div className="col-md-4">
         <h1>Name: {this.props.coursedetails.name}</h1>
         <img src={this.props.coursedetails.image} width="100 px" height="100 px"/>
         <h2>Price: {this.props.coursedetails.price}</h2>
         <button className="btn btn-primary" onClick={this.IncreementLikes.bind(this)}>
         {this.props.coursedetails.likes}
        
        

             
             <span className="glyphicon glyphicon-thumbs-up"></span></button>
             <h2>Location: {this.props.coursedetails.location}</h2>
                   <button className="btn btn-danger btn-sm" onClick={this.DeleteCourse1.bind(this)}>
        Delete me {this.props.coursedetails.courses}
        >
              <span className="glyphicon glyphicon-trash"></span></button>
              
         </div>
    }
}
// export function Add(x,y){
// return x+y;
// }