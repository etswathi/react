import React from 'react'

export const FuncComponent = (props) => {
    return(
        <div>
        <h1>Functional Component{props.msg}</h1>
        </div>
    )
}
  export default FuncComponent