import React from 'react'
import axios from 'axios'

export default class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = { posts: [] }
    }

    componentDidMount() {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(
            // response => console.log(response.data)  //displayed in console
            response => this.setState({ posts: response.data })  //to display in ui
        )
    }

DeleteHandler(postToBeDeletedid)
{let newPostsList=this.state.posts.filter(currentPost=>currentPost.id!=postToBeDeletedid)
    this.setState({posts:newPostsList})
}



    render() {
        var postsToBeCreated = this.state.posts.map(p => <li key ={p.id}>{p.title}
        <button className="btn btn-danger btn-sm"
        onClick={this.DeleteHandler.bind(this,p.id)}>
        <span className="glyphicon glyphicon-trash"></span>
        </button></li>)
        return <div>
            <h1>All Posts</h1>
            <ul>
                {postsToBeCreated}
            </ul>
        </div>

    }
}