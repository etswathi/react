
 let theIndex;
export function courses(defStore=[],action){


switch(action.type)
{
    case 'INCREMENT_LIKES':
   //FIND ELEMENT/INDEX TO INCREMENT LIKES

    theIndex=defStore.findIndex(c=>c.id==action.theId);
   return[
       ...defStore.slice(0,theIndex),
       {...defStore[theIndex],likes:defStore[theIndex].likes+1},
       ...defStore.slice(theIndex+1)
   ];
    //return defStore;

case 'DELETE_COURSE':


    theIndex=defStore.findIndex(c=>c.id==action.theId);
   return[
       ...defStore.slice(0,theIndex),
       ...defStore.slice(theIndex+1)
   ];
 

    //console.log('within reducer delete course')
    //console.log(action)
    //return defStore;
    

case 'FETCH_COURSES':


    
   return action.response;





    
    
    default:
return defStore;}



}



