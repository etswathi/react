 let theIndex;

export function posts(defStore=[],action){


switch(action.type)
{
    case 'DELETE_POST':
    theIndex=defStore.findIndex(p=>p.id==action.theId);
    console.log(theIndex)
   return[
       ...defStore.slice(0,theIndex),
       ...defStore.slice(theIndex+1)
   ];
 



case 'FETCH_POST':
return action.response;




default:
return defStore;}}
