//create store method

//createStore()
import{createStore} from 'redux';
import{rootreducer} from '../reducers/rootreducer'

var defaultStoreData={

    courses:[
// {id:1,name: 'Java', image: "https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png", price: 3000, likes: 1000, location: "pune" },
// {id:2,name: '.Net', image: "https://s3.amazonaws.com/dev.assets.neo4j.com/wp-content/uploads/dotnet-logo.png", price: 4000, likes: 2000, location: "Bangalore" },
// {id:3,name: 'Python', image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7BLm4Poe8sSsOaUdrLDpG73RInz0yX20xxETXA4dbjTKohIn8&s", price: 3000, likes: 1000, location: "pune" }

    ],
    posts:[
// {id:1,name:'dummy'}
    ]}

//createStore(reducer,defStoreData)
export var store=createStore(rootreducer,defaultStoreData);