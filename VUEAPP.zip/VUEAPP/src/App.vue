<template>
 <!--<ListOfCourses />-->
 <!--<posts />-->
 <!--<blog>-->
<!--<template v-slot:header>
  <template #header>

  <h2>header for blog 1</h2>
  </template>
  <template v-slot:mainarticle>
  <div>mainarticle for blog 1<br>
  mainarticle for blog 1
  mainarticle for blog 1
  mainarticle for blog 1
  mainarticle for blog 1
  </div>
  </template>
  <template v-slot:footer>
  <h4>footer for blog 1</h4>
  </template>
  </blog>-->
<div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!--<div class="navbar-header">
      <Link class="navbar-brand" to="/">Online Shopping</Link>
    </div>-->
    <ul class="nav navbar-nav">
      <li><router-link to="/">Home</router-link></li>
       <li><router-link to="/posts">Posts</router-link></li>
     
    </ul>
  </div>
</nav>








<div>
  <router-view></router-view>
  </div></div>
</template>

<script>
//import HelloWorld from './components/HelloWorld.vue'

//import ListOfCourses from './components/listofcourses'
//import posts from './components/posts.component'
//import blog from './components/blog.component'
export default {
  name: 'app',
  components: {
    //ListOfCourses,
   // posts,
   //blog,
  },
   
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  
  color: #2c3e50;
  margin-top: 60px;
}
</style>
