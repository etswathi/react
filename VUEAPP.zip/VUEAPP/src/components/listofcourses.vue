<template>
    <div>
    <div class="jumbotron">
    <h1>Online Courses</h1>
    <img :src="img" width="500 px" height="100 px"/>
    </div>
    
  <div id="app" class="row">
   <div v-for="course in courses" :key="course.id" class="col-md-4">
       <course :course-details="course" @delete-a-course ="Deletecourseparent($event)"></course>
  </div>
  </div></div>
</template>

<script>
import Course from './course.component.vue'
    export default {

          
        name:'ListOfCourses',
        components:{Course},




methods:{
    Deletecourseparent(theid){
        alert('deleted'+ theid)
        this.courses=this.courses.filter(course=>course.id!=theid);
    }

},
      
 data(){
    return{
      courses:[{id:1, name: 'JAVA', image: "https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png", price: 3000, likes: 1000, location: "pune" },
{id:2,name: '.Net', image: "https://s3.amazonaws.com/dev.assets.neo4j.com/wp-content/uploads/dotnet-logo.png", price: 4000, likes: 2000, location: "Bangalore" },
{id:3,name: 'Python', image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7BLm4Poe8sSsOaUdrLDpG73RInz0yX20xxETXA4dbjTKohIn8&s", price: 3000, likes: 1000, location: "pune" }],
img : "https://theme.zdassets.com/theme_assets/1073405/5ca1ed9007049470043d5b8b85ba79d081e268a4.png"
      

      
  }}
  }










 
</script>

<style scoped>

</style>