<template>
    <div>
        <div class="jumbotron">
            <h1>All post details for {{postId}}</h1><br>
            <strong>{{thePost.title}}</strong><br>
              <strong>{{thePost.userId}}</strong><br>
               <strong>{{thePost.body}}</strong><br>
    </div>
    </div>
 
</template>

<script>


    export default {
        name:'postdetails',
      data() {
        return {
            postId: this.$route.params.id,
            thePost: []
        }
    },
    beforeMount() {
        this.thePost = JSON.parse(localStorage['Post']).find(p => p.id == this.postId)
    }

    }
</script>

<style scoped>

</style>