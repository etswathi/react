<template>
    <div>
        <div class="jumbotron">
            <h1>All posts</h1>
    </div>
    <ul>
    <li v-for="p in allposts" :key="p.id"><router-link :to="{name:'postdetails',params:{id:p.id}}">{{p.title}}</router-link></li>
    </ul>
    </div>
</template>

<script>
import axios from 'axios'

    export default {
        name:'postdetails',

        data(){
            return{
                allposts:[]
        }},
      mounted() {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(response => {this.allposts = response.data;
         localStorage['Post']=JSON.stringify(response.data) }
        )
       
    }}
        
        
          

 
</script>

<style scoped>

</style>