import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router';
import ListOfCourses from './components/listofcourses'
import posts from './components/posts.component'
import postdetails from './components/postdetails.component'




Vue.config.productionTip = false
Vue.filter('currency',function(val){
  return `Rs. ${val}`
});
Vue.use(VueRouter);

const routes = [
  {path:"",component:ListOfCourses},
   {path:'/postdetails/:id',component:postdetails,name:'postdetails'},
  {path:'/posts',component:posts},
  {path:"*",redirect:"/"}
];

var router = new VueRouter({
  routes,
  mode:'history'
})





new Vue({
  render: h => h(App),
  router
}).$mount('#app')
