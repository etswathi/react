

<template>
  <div id="app"> 

    <ListOfCourses></ListOfCourses>
    
  </div>
</template>

<script>
import ListOfCourses from './components/listofcourses.vue'

export default {
  name: 'app',
  components: {
    ListOfCourses
    
  }
}
</script>

<style>

</style>
