<template>
        
    <div >
        
        <div :class="['courseStyle',{'Greenish':hi}]">
            
<h1>{{courseDetails.name | allowercase | allcaps }}</h1>
<h5>Add to cart <input type="checkbox" v-model="hi" /></h5>
 <img :src="courseDetails.image" width="100 px" height="100 px"/><br>
IsFree ? :<input type="checkbox" v-model="IsFree"/>
 <div v-show="!IsFree">

<h2>{{courseDetails.price | currency}}</h2>

</div>



<!--<div v-else>
    <strong style="color:darkred">Course is free!!!come on !!!!!grab ur seats.....</strong>
    </div>-->

<h2>{{courseDetails.location}}</h2>
 <button class="btn btn-primary" @click="IncrementLikes">  <span class="glyphicon glyphicon-thumbs-up">{{courseDetails.likes}}</span></button>
  <button class="btn btn-danger" @click="Deletecourse">  <span class="glyphicon glyphicon-trash">Delete me</span></button>

</div>
    </div>
    

</template>

<script>
    export default {
        name:'Course',
    data()
    {
        return{hi:false,
               IsFree:false
              
              }
        
    },
        props:{
            // courseName:{

            //     type:String,
            //     default:'Angular'
            // }
       
    courseDetails:{
        type:Object
    },
    
    
 },
 methods:{
     IncrementLikes:function(){
    //  this.courseDetails.likes++;
    this.$store.commit('incrementLikes',this.courseDetails.id)
 },
     Deletecourse:function(){

        // this.$emit('delete-a-course',this.courseDetails.id);
          this.$store.commit('Deletecourse',this.courseDetails.id)

     }


},
 filters:{
     allcaps(val){
         return val.toUpperCase();
     },
    allowercase(val){
         return val.toLowerCase();  
 }
 

        
    }}
</script>

<style scoped>
.courseStyle{
    border:2px solid grey;
    border-radius:10px;
    margin-left:10px;
    padding:10px;
    box-shadow:10px 10px 10px darkslategray;
}

.Greenish{background-color:burlywood; border:2px solid grey;
    border-radius:10px;
    margin-left:10px;
    padding:10px;
    box-shadow:10px 10px 10px darkslategray;}



</style>