import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);


//state,mutations,actions,getters
export const store=new Vuex.Store({
state:{
    courses:[]
},
mutations:{
    incrementLikes(state,args){
//to increment likes of courses
let index=state.courses.findIndex(c=>c.id==args);
state.courses[index].likes++;
    // alert('inside increment likes mutation'+ state+ args)



    },
      Deletecourse(state,args){



     state.courses=state.courses.filter(course=>course.id!=args);
     

      },


    setCourses(state,args){
        // alert('inside setCourses mutation');

state.courses=args;
    }
    
},

actions:{
    getCoursesAsync({commit}){
        // alert('making ajax request')
        //ajax request

        axios.get('https://api.myjson.com/bins/19ab30')
        .then(response => commit('setCourses',response.data))
    }



},
getters:{
    totalCount:state=>state.courses.length

}

});